# JavaScript Test App

This is a simple web app skeleton which you can use to test how to reference, initialize and use the Glue42 library in your apps.

# Running the App

1. Open a command prompt in the root app directory and run `npm install`. This will install the `http-server` package which will be needed to serve the app.

2. In the same command prompt, run `npm start`. This will start a local server at port 3333 where the app will be hosted.

3. Initialize the Glue42 library by following this [quick guide](https://docs.glue42.com/getting-started/how-to/glue42-enable-your-app/overview/index.html)

3. To add the test app to the list of applications in the **Glue42 Enterprise** Toolbar, copy the `js-test-app.json` configuration file in `%LocalAppData%\Tick42\UserData\<ENV-REG>\apps` where `<ENV-REG>` should be replaced with the environment and region folder name of your **Glue42 Enterprise** installation, e.g., `T42-DEMO`.

4. Start **Glue42 Enterprise** (if **Glue42 Enterprise** is running, the configuration changes will be automatically detected and your app will be automatically added to the list of available apps in the App Manager).

5. Start the app from the App Manager or view it in a browser at this address: `"http://localhost:3333/test-app.html"`.