const values = document.getElementsByName("values");

setInterval(fakeData, 2000);

function fakeData() {
    [...values].map(v => v.textContent = (Math.random() * 100).toFixed(2) + " units");
};